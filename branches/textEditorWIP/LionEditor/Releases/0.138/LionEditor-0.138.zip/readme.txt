Lion Editor v0.138

See http://code.google.com/p/lioneditor/wiki/Instructions for instructions.

New since v0.107
    Can now modify each character's kills. Useful for unlocking Dark Knight.
    Fixed inventory issue where the Fitting Room stopped working
    Fixed bug where you couldn't increase Speed

New since v0.95:
    Fixed issue where Artefacts get messed up
    Changed kernel plugin behavior, now it places a file called 
        "lioneditor.bin" in PSP/SAVEDATA/ULUS10297FFT0000/ right next to the 
        other files
    Added plugin installer to the main application: click the icon, select 
        the drive where your memory stick is, and it will install the plugin.
    Added Character Browser window
        Can open PSP or Playstation files (DexDrive/GME only)
        Drag and drop a character's name from the browser to the main Lion
            Editor window to copy the character to the save you are 
            editing
    Added drag/drop/copy/paste support to Character editing screen
        Drag and Drop a character's name within the editor to rearrange characters
        Right click on a character's name and select Copy, then right click on a
            another character and select Paste. The first character's data 
            will be copied over the second character's.
    Added "Open from Memory Stick" button. Click the arrow next to the button
        and select what region your copy of War of the Lions is. Then select
        what drive your Memory Stick is in, and it will open the decrypted file
        if it exists.
    Added Random Name generator
        The names it generates are based on the character's current Gender

New since v0.82:
    Bug fixes
    Added tooltip for Move, Jump, Speed, HP, MP, PhysAttk, and MagicAttack
    Added Feats editor
    Added Wonders editor
    Added Artefacts editor
    Added Inventory editor
    Added Poacher's Den editor
    Added in-game Options editor

Future features planned:
    Errands
    Chronicle (Personae, Events)
    Import saves from Playstation version
    
If you find any bugs, please fill out an issue report at 
http://code.google.com/p/lioneditor/issues/list

Attach a copy of your lioneditor.bin if you think it will help me reproduce the 
problem. Also indicate what version of the game you are using 
(US/Europe/Japan).
