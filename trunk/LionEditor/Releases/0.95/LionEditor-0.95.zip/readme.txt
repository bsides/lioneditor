Lion Editor v0.95

See http://code.google.com/p/lioneditor/wiki/Instructions for instructions.

New since v0.82:
	Bug fixes
	Added tooltip for Move, Jump, Speed, HP, MP, PhysAttk, and MagicAttack
	Added Feats editor
	Added Wonders editor
	Added Artefacts editor
	Added Inventory editor
	Added Poacher's Den editor
	Added in-game Options editor

Future features planned:
	Copy characters from one save to another
	Errands
	Chronicle (Personae, Events)
	Import saves from Playstation version
	
If you find any bugs, please fill out an issue report at 
http://code.google.com/p/lioneditor/issues/list

Attach a copy of your FFTA.SYS if you think it will help me reproduce the 
problem. Also indicate what version of the game you are using 
(US/Europe/Japan).
